/**
 * Opti-On: Sui demo script.
 *
 *   npx tsx opti.ts setup                         backend opens a challenge (RMSNorm on RTX 4090)
 *   npx tsx opti.ts submit [kernel-file]          tuner submits a kernel hash + stake
 *   npx tsx opti.ts settle <submissionId> <v1,v2,v3> [--fail]
 *                                                 THE PTB: refund stake + pay verifiers + set #1
 *                                                 --fail passes only 2 verifiers -> whole PTB aborts
 *   npx tsx opti.ts hack <submissionId>           attacker tries set_leader with our AdminCap -> rejected
 *   npx tsx opti.ts buy                           buyer pays for the #1 kernel
 *   npx tsx opti.ts claim <tunerAddr> <payoutAddr>
 *                                                 backend pays royalties out (after World ID check)
 *   npx tsx opti.ts status                        show who is #1
 *
 * Config comes from .env (see .env.example).
 */
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { bcs } from '@mysten/sui/bcs';
import { SuiGrpcClient } from '@mysten/sui/grpc';
import { Ed25519Keypair } from '@mysten/sui/keypairs/ed25519';
import { Transaction } from '@mysten/sui/transactions';

try {
	process.loadEnvFile();
} catch {
	/* no .env file, use real env vars */
}

// ---------- config ----------
const NETWORK = process.env.SUI_NETWORK ?? 'testnet';
const URLS: Record<string, string> = {
	mainnet: 'https://fullnode.mainnet.sui.io:443',
	testnet: 'https://fullnode.testnet.sui.io:443',
	devnet: 'https://fullnode.devnet.sui.io:443',
	localnet: 'http://127.0.0.1:9000',
};
const client = new SuiGrpcClient({ network: NETWORK, baseUrl: URLS[NETWORK] });

// Small amounts so a faucet top-up is plenty. 1 SUI = 1_000_000_000 MIST.
const PRICE = 10_000_000n; // 0.01 SUI per purchase
const STAKE = 5_000_000n; // 0.005 SUI stake per submission
const VERIFIER_PAY = 3_000_000n; // 0.003 SUI split between verifiers
const FEE_BPS = 250; // Opti-On keeps 2.5%

function env(name: string): string {
	const v = process.env[name];
	if (!v) throw new Error(`Missing ${name} in .env`);
	return v;
}
const key = (name: string) => Ed25519Keypair.fromSecretKey(env(name));
const target = (fn: string) => `${env('PACKAGE_ID')}::market::${fn}` as const;

const Submitted = bcs.struct('Submitted', {
	challenge: bcs.Address,
	submission: bcs.Address,
	tuner: bcs.Address,
	code_hash: bcs.vector(bcs.u8()),
});

// Abort codes from market.move, so failures read in plain words.
const ERRORS: Record<string, string> = {
	'0': 'EWrongStake: stake is not the required amount',
	'1': 'ENoLeader: no kernel has been verified and set as #1 yet',
	'2': 'EWrongPrice: payment is not the listed price',
	'3': 'ENothingToClaim: this tuner has no royalties',
	'4': 'ETooFewVerifiers: fewer than 3 verifiers agreed',
	'5': 'EPaymentTooSmall: verifier payment too small to split',
	'6': 'EBadFee: fee above 100%',
};

// ---------- helper: sign, send, print ----------
async function send(signer: Ed25519Keypair, tx: Transaction, label: string) {
	let res;
	try {
		res = await client.signAndExecuteTransaction({
			signer,
			transaction: tx,
			include: { effects: true, events: true, objectTypes: true },
		});
	} catch (e) {
		// Before sending, the SDK asks Sui to simulate the transaction.
		// If any step would abort, Sui refuses it and nothing is submitted.
		const err = e as Error & { executionError?: { MoveAbort?: { abortCode: string }; message?: string } };
		const abort = err.executionError?.MoveAbort;
		if (!abort) throw e;
		const fn = err.executionError?.message?.match(/::market::(\w+)/)?.[1] ?? 'a step';
		console.log(`FAILED ${label}`);
		console.log(`       ${fn} aborted: ${ERRORS[abort.abortCode] ?? `abort code ${abort.abortCode}`}`);
		console.log('       Sui refused the whole transaction, so none of its steps happened.');
		return null;
	}
	const t = res.Transaction ?? res.FailedTransaction!;
	await client.waitForTransaction({ digest: t.digest });
	const ok = t.status.success;
	console.log(`${ok ? 'OK    ' : 'FAILED'} ${label}`);
	console.log(`       tx: ${t.digest}`);
	if (NETWORK !== 'localnet') console.log(`       https://suiscan.xyz/${NETWORK}/tx/${t.digest}`);
	if (!t.status.success) {
		console.log(`       reason: ${t.status.error.message}`);
		console.log('       nothing in this transaction happened (only gas was spent)');
	}
	return t;
}

// ---------- commands ----------
async function setup() {
	const tx = new Transaction();
	tx.moveCall({
		target: target('create_challenge'),
		arguments: [
			tx.object(env('ADMIN_CAP_ID')),
			tx.pure.string('RMSNorm'),
			tx.pure.string('RTX 4090'),
			tx.pure.u64(PRICE),
			tx.pure.u64(FEE_BPS),
			tx.pure.u64(STAKE),
		],
	});
	const t = await send(key('ADMIN_KEY'), tx, 'create challenge: RMSNorm on RTX 4090');
	if (!t) return;
	const created = t.effects!.changedObjects.filter((o) => o.idOperation === 'Created');
	const ch = created.find((o) => t.objectTypes?.[o.objectId]?.endsWith('::market::Challenge'));
	console.log(`\nAdd this to .env:\nCHALLENGE_ID=${ch?.objectId}`);
}

async function submit(file?: string) {
	const data = file && existsSync(file) ? readFileSync(file) : Buffer.from(file ?? 'demo-kernel-v1');
	const hash = createHash('sha256').update(data).digest();

	const tx = new Transaction();
	const [stake] = tx.splitCoins(tx.gas, [STAKE]);
	tx.moveCall({
		target: target('submit'),
		arguments: [tx.object(env('CHALLENGE_ID')), tx.pure.vector('u8', [...hash]), stake],
	});
	const t = await send(key('TUNER_KEY'), tx, `tuner submits kernel sha256:${hash.toString('hex').slice(0, 16)}...`);
	const ev = t?.events?.find((e) => e.eventType.endsWith('::market::Submitted'));
	if (ev) console.log(`\nSubmission id: ${Submitted.parse(ev.bcs).submission}`);
}

/**
 * THE PROGRAMMABLE TRANSACTION BLOCK.
 * Called by our backend after the harness passes and 3 of 5 verifiers agree.
 * Three Move calls, one transaction: all happen, or none do.
 */
async function settle(submission: string, verifierList: string, fail: boolean) {
	let verifiers = verifierList.split(',').map((s) => s.trim());
	if (fail) verifiers = verifiers.slice(0, 2); // only 2 verifiers -> step 2 aborts

	const tx = new Transaction();
	const cap = tx.object(env('ADMIN_CAP_ID'));
	const ch = tx.object(env('CHALLENGE_ID'));

	// 1. return the tuner's stake
	tx.moveCall({ target: target('refund_stake'), arguments: [cap, ch, tx.pure.id(submission)] });
	// 2. pay the verifiers who agreed (coin split off the backend's gas coin)
	const [pay] = tx.splitCoins(tx.gas, [VERIFIER_PAY]);
	tx.moveCall({
		target: target('pay_verifiers'),
		arguments: [cap, pay, tx.pure.vector('address', verifiers)],
	});
	// 3. make this kernel #1
	tx.moveCall({ target: target('set_leader'), arguments: [cap, ch, tx.pure.id(submission)] });

	await send(
		key('ADMIN_KEY'),
		tx,
		`settle PTB: refund stake + pay ${verifiers.length} verifiers + set #1${fail ? '  (break: only 2 verifiers)' : ''}`,
	);
}

/** Someone who is not our backend tries to crown their own kernel. */
async function hack(submission: string) {
	const tx = new Transaction();
	tx.moveCall({
		target: target('set_leader'),
		arguments: [tx.object(env('ADMIN_CAP_ID')), tx.object(env('CHALLENGE_ID')), tx.pure.id(submission)],
	});
	try {
		await send(key('ATTACKER_KEY'), tx, 'attacker calls set_leader using our AdminCap');
	} catch (e) {
		console.log('REJECTED attacker calls set_leader using our AdminCap');
		console.log(`       Sui: ${(e as Error).message.split('\n')[0]}`);
		console.log('       The attacker does not own the AdminCap, so Sui refuses the transaction.');
	}
}

async function buy() {
	const tx = new Transaction();
	const [pay] = tx.splitCoins(tx.gas, [PRICE]);
	tx.moveCall({ target: target('buy'), arguments: [tx.object(env('CHALLENGE_ID')), pay] });
	await send(key('BUYER_KEY'), tx, `buyer pays ${Number(PRICE) / 1e9} SUI for the #1 kernel`);
}

async function claim(tuner: string, payout: string) {
	// TODO in backend: verify the tuner's World ID session proof first
	// (session_id matches the one saved at sign-up, signal == payout address,
	// nullifier not used before). Only then send this transaction.
	const tx = new Transaction();
	tx.moveCall({
		target: target('claim_to'),
		arguments: [tx.object(env('ADMIN_CAP_ID')), tx.object(env('CHALLENGE_ID')), tx.pure.address(tuner), tx.pure.address(payout)],
	});
	await send(key('ADMIN_KEY'), tx, `pay royalties of ${tuner.slice(0, 10)}... to ${payout.slice(0, 10)}...`);
}

async function status() {
	const { object } = await client.getObject({ objectId: env('CHALLENGE_ID'), include: { json: true } });
	const j = object.json as Record<string, unknown>;
	console.log(`Challenge: ${j.task} on ${j.gpu}`);
	console.log(`#1 kernel: ${JSON.stringify(j.leader)}`);
	console.log(`#1 tuner:  ${JSON.stringify(j.leader_tuner)}`);
}

// ---------- CLI ----------
const [cmd, ...args] = process.argv.slice(2);
const commands: Record<string, () => Promise<void>> = {
	setup,
	submit: () => submit(args[0]),
	settle: () => settle(args[0], args[1], args.includes('--fail')),
	hack: () => hack(args[0]),
	buy,
	claim: () => claim(args[0], args[1]),
	status,
};
if (!cmd || !commands[cmd]) {
	console.log('Usage: npx tsx opti.ts <setup|submit|settle|hack|buy|claim|status> [args]');
	process.exit(1);
}
commands[cmd]().catch((e) => {
	console.error(e);
	process.exit(1);
});
